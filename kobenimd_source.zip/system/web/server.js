import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { listBot } from "../../outdex.js";

const MAX_LOGS = 200;
const logBuffer = [];

// Intercept console.log and console.error to show in web dashboard
const origLog = console.log;
const origErr = console.error;

console.log = (...args) => {
  origLog(...args);
  const msg = args.map(a => (typeof a === "object" ? JSON.stringify(a) : String(a))).join(" ");
  logBuffer.push({ time: new Date().toLocaleTimeString(), type: "log", msg });
  if (logBuffer.length > MAX_LOGS) logBuffer.shift();
};

console.error = (...args) => {
  origErr(...args);
  const msg = args.map(a => (typeof a === "object" ? JSON.stringify(a) : String(a))).join(" ");
  logBuffer.push({ time: new Date().toLocaleTimeString(), type: "error", msg });
  if (logBuffer.length > MAX_LOGS) logBuffer.shift();
};

export function startWebServer(port = 3000) {
  const rootDir = process.cwd();

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    const pathname = url.pathname;

    // CORS headers for local/iFrame interaction
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");

    if (req.method === "OPTIONS") {
      res.writeHead(204);
      return res.end();
    }

    // Static Index
    if (pathname === "/" || pathname === "/index.html") {
      try {
        const html = fs.readFileSync(path.join(rootDir, "index.html"), "utf8");
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        return res.end(html);
      } catch (err) {
        res.writeHead(500, { "Content-Type": "text/plain" });
        return res.end("Error reading index.html: " + err.message);
      }
    }

    // Static Media
    if (pathname.startsWith("/media/")) {
      const fileName = path.basename(pathname);
      const filePath = path.join(rootDir, "system", "media", fileName);
      if (fs.existsSync(filePath)) {
        const ext = path.extname(filePath).toLowerCase();
        const mimeTypes = {
          ".jpg": "image/jpeg",
          ".jpeg": "image/jpeg",
          ".png": "image/png",
          ".webp": "image/webp"
        };
        res.writeHead(200, { "Content-Type": mimeTypes[ext] || "application/octet-stream" });
        return fs.createReadStream(filePath).pipe(res);
      } else {
        res.writeHead(404, { "Content-Type": "text/plain" });
        return res.end("Not found");
      }
    }

    // API Status
    if (pathname === "/api/status" && req.method === "GET") {
      const pluginsList = global.plugins || {};
      const payload = {
        status: "online",
        botName: "Kobeni-MD",
        uptime: Math.floor(process.uptime()),
        commandsCount: Object.keys(pluginsList).length,
        owner: global.owner || "601112260297",
        prefix: global.prefix || [".", "!", "/"],
        pairingCode: global.pairingcode || "KOBENIMD",
        subBots: typeof listBot === "function" ? listBot() : [],
        memory: {
          rss: Math.round(process.memoryUsage().rss / 1024 / 1024) + " MB",
          heapUsed: Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + " MB"
        },
        nodeVersion: process.version
      };
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify(payload));
    }

    // API Commands
    if (pathname === "/api/commands" && req.method === "GET") {
      const pluginsList = global.plugins || {};
      const cmds = [];
      for (const [cmd, info] of Object.entries(pluginsList)) {
        cmds.push({
          command: cmd,
          name: info.name,
          category: info.category
        });
      }
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ total: cmds.length, commands: cmds }));
    }

    // API Logs
    if (pathname === "/api/logs" && req.method === "GET") {
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ logs: logBuffer }));
    }

    // API Test Command Simulator
    if (pathname === "/api/test-command" && req.method === "POST") {
      let body = "";
      req.on("data", chunk => { body += chunk; });
      req.on("end", async () => {
        try {
          const data = JSON.parse(body || "{}");
          const input = (data.command || "").trim();
          if (!input) {
            res.writeHead(400, { "Content-Type": "application/json" });
            return res.end(JSON.stringify({ error: "Missing command input" }));
          }

          // Strip prefix if given
          let cleanCmd = input;
          const prefixes = global.prefix || [".", "!", "/"];
          for (const p of prefixes) {
            if (cleanCmd.startsWith(p)) {
              cleanCmd = cleanCmd.slice(p.length);
              break;
            }
          }
          const parts = cleanCmd.split(/\s+/);
          const cmdName = parts[0].toLowerCase();
          const args = parts.slice(1);
          const text = args.join(" ");

          const plugin = global.plugins?.[cmdName];
          if (!plugin) {
            res.writeHead(404, { "Content-Type": "application/json" });
            return res.end(JSON.stringify({
              error: `Command '${cmdName}' not found in plugins`,
              available: Object.keys(global.plugins || {}).slice(0, 10)
            }));
          }

          const replies = [];
          const mockM = {
            chat: "web-test@s.whatsapp.net",
            sender: (global.owner || "601112260297") + "@s.whatsapp.net",
            pushName: "Web User",
            text: text,
            isGroup: false,
            reply: async (msg) => {
              replies.push(typeof msg === "string" ? msg : JSON.stringify(msg));
            }
          };

          const mockConn = {
            user: { id: (global.owner || "601112260297") + ":1@s.whatsapp.net" },
            decodeJid: (jid) => jid?.split(":")[0] || jid,
            sendMessage: async (chat, content) => {
              if (content.text) replies.push(content.text);
              else if (content.caption) replies.push(content.caption);
              else replies.push("[Media / Complex Message Sent]");
            }
          };

          const options = {
            conn: mockConn,
            isBotAdmins: true,
            isAdmins: true,
            command: cmdName,
            args: args,
            text: text,
            isAccess: true,
            isMainAccess: true,
            prefix: "."
          };

          await plugin.handler(mockM, options);

          res.writeHead(200, { "Content-Type": "application/json" });
          return res.end(JSON.stringify({
            success: true,
            command: cmdName,
            replies: replies.length > 0 ? replies : ["Command completed with no text reply."]
          }));
        } catch (err) {
          res.writeHead(500, { "Content-Type": "application/json" });
          return res.end(JSON.stringify({
            error: err.message,
            stack: err.stack
          }));
        }
      });
      return;
    }

    // Health check endpoint
    if (pathname === "/health") {
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ status: "healthy", timestamp: Date.now() }));
    }

    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("Not Found");
  });

  server.listen(port, "0.0.0.0", () => {
    console.log(`[ WEB ] Kobeni-MD Dashboard running at http://0.0.0.0:${port}`);
  });

  return server;
}
