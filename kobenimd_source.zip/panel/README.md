# 🌸 Kobeni-MD Web Control Panel (Anime Pixel VPS Edition)

An intuitive, secure, and real-time Web Control Panel & Admin Console for the **Kobeni-MD** WhatsApp Multi-Device bot running on a VPS or cloud server.

Designed with a retro **Japanese Anime Pixel Art** aesthetic and built on top of Express, WebSocket/SSE, and modern responsive web technologies.

---

## 🌟 Key Features

1. **Main Bot Lifecycle Control**:
   - Start, Stop, and Restart the primary Baileys WhatsApp process.
   - Live state detection: `ONLINE`, `CONNECTING`, `PAIRING`, `RECONNECTING`, `STOPPED`, `CRASHED`.
   - Real PID, process uptime, memory RSS, reconnect counters, and auto-recovery.
   - Live WhatsApp pairing code display for seamless device linking.

2. **Multi-Device Clone Management**:
   - Manage clone bots stored in `session/bots/<number>/`.
   - Add new clone bot with country-code validation.
   - Real-time WhatsApp pairing code generation directly from Baileys.
   - Delete clone bot with explicit confirmation modal.

3. **Public / Self Mode Controller**:
   - View and toggle mode between `PUBLIC` (open for everyone) and `SELF` (restricted access).
   - Modifies `system/database/public.json` and `public_<id>.json` directly via `system/lib/access.js`.

4. **Access Control Management**:
   - List authorized WhatsApp numbers for Main Bot and each individual Clone Bot.
   - Add new numbers with validation (5-20 digits).
   - Delete/revoke user access with confirmation.

5. **Plugin & Command Explorer**:
   - Real-time scanner for `system/plugins/` (AI, Anime, Download, Manga, Search, SysInfo, Tools, WAControl, etc.).
   - Category filtering, command alias search, and file modification metadata.

6. **Real-Time Log Stream with Sensitive Redaction**:
   - Live SSE / WebSocket log streaming.
   - Filter by log level: `ALL`, `INFO`, `BOT`, `CLONE`, `WARN`, `ERROR`.
   - **Zero Secret Leaks**: Automatic cryptographic masking of API keys (`sk-...`, `AIzaSy...`), authorization tokens, passwords, cookies, and WhatsApp session credentials.
   - Controls: Pause stream, auto-scroll toggle, copy logs, and clear visual terminal.

7. **VPS & Hardware Telemetry**:
   - Live CPU % utilization gauge and core count.
   - RAM memory usage (used, free, total, percentage).
   - Disk storage space monitor (`statfs`).
   - Node.js runtime telemetry: PID, V8 Heap, RSS memory, host load average (1m, 5m, 15m).

8. **Security & Hardening**:
   - Secure login with PBKDF2 password hashing with salt.
   - Constant-time string comparison against timing attacks.
   - Signed HMAC-SHA256 session tokens with expiration.
   - Login rate-limiter (brute-force defense) & mutation rate-limiters.
   - Strict path traversal defense on all parameters.
   - Audit logging for all administrative actions.

---

## 🚀 Getting Started

### 1. Installation

Dependencies are installed via npm:

```bash
npm install
```

### 2. Configuration

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Edit your desired credentials:
```env
PANEL_PORT=3000
PANEL_ADMIN_USERNAME=admin
PANEL_ADMIN_PASSWORD=your_secure_password
```

### 3. Run the Bot with Control Panel

To start Kobeni-MD alongside the Web Control Panel:

```bash
npm start
# or
npm run dev
```

To run the panel standalone:

```bash
npm run panel
```

The panel will be live at: `http://localhost:3000` (or `http://YOUR_VPS_IP:3000`).

---

## 🧪 Testing

Run the automated smoke test suite:

```bash
npm test
```

This verifies authentication, token validation, sensitive redaction, system metrics, access control mutations, plugin scanner, and bot process manager.

---

## 🌐 Nginx Reverse Proxy Setup (Optional for VPS)

```nginx
server {
    listen 80;
    server_name panel.yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }

    # Enable SSE streaming
    location /api/events {
        proxy_pass http://127.0.0.1:3000/api/events;
        proxy_buffering off;
        proxy_cache off;
        proxy_set_header Connection '';
        proxy_http_version 1.1;
        chunked_transfer_encoding off;
    }
}
```

---

## 🌸 Mascot Assistant
The panel features an original vector pixel-art mascot of **Kobeni** who actively changes expressions (Happy, Worried, Panicking, or Alert) based on the live operational health of your WhatsApp bot!
