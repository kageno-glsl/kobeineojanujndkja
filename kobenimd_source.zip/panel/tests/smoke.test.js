// Comprehensive Smoke Test for Kobeni-MD Web Control Panel (Single Google Admin)
import assert from "node:assert";
import { authService } from "../server/services/authService.js";
import { kobeniService } from "../server/services/kobeniService.js";
import { botProcessManager } from "../server/services/botProcessManager.js";
import { systemMonitor } from "../server/services/systemMonitor.js";
import { redactSensitive } from "../server/services/logService.js";

async function runTests() {
  console.log("=== STARTING KOBENI-MD SINGLE ADMIN CONTROL PANEL SMOKE TESTS ===\n");
  let passed = 0;
  let failed = 0;

  function test(name, fn) {
    try {
      fn();
      console.log(`  ✓ ${name}`);
      passed++;
    } catch (err) {
      console.error(`  ✗ ${name}: ${err.message}`);
      failed++;
    }
  }

  async function testAsync(name, fn) {
    try {
      await fn();
      console.log(`  ✓ ${name}`);
      passed++;
    } catch (err) {
      console.error(`  ✗ ${name}: ${err.message}`);
      failed++;
    }
  }

  const configuredAdmin = authService.getAdminEmail();

  // 1. Single Admin Google Auth Tests
  await testAsync("Auth: Exact match authorized admin Google account succeeds", async () => {
    process.env.NODE_ENV = "test";
    const profile = { email: configuredAdmin, displayName: "Owner", uid: "google-admin-123" };
    const session = await authService.authenticateGoogleUser("mock-valid-id-token", profile);
    
    assert.ok(session.token, "Session token must be generated");
    assert.strictEqual(session.email, configuredAdmin);
    assert.strictEqual(session.role, "admin");

    const verified = authService.verifyToken(session.token);
    assert.ok(verified, "Session token must be verifiable");
    assert.strictEqual(verified.email, configuredAdmin);
  });

  await testAsync("Auth: Unauthorized Google email must be strictly denied (Exact Match)", async () => {
    process.env.NODE_ENV = "test";
    const intruderProfile = { email: "intruder@gmail.com", displayName: "Intruder", uid: "google-intruder-456" };
    
    await assert.rejects(async () => {
      await authService.authenticateGoogleUser("mock-id-token", intruderProfile);
    }, (err) => {
      return err.code === "ADMIN_EMAIL_NOT_ALLOWED" || err.message.includes("not authorized");
    }, "Unauthorized email must be rejected with ACCESS_DENIED");
  });

  test("Auth: Tampered token must be rejected", () => {
    const { token } = authService.createTestAdminSession(configuredAdmin);
    const tampered = token.slice(0, -4) + "abcd";
    const session = authService.verifyToken(tampered);
    assert.strictEqual(session, null, "Tampered token must return null");
  });

  test("Auth: Revoked session must not be accepted", () => {
    const { token } = authService.createTestAdminSession(configuredAdmin);
    authService.revokeSession(token);
    const session = authService.verifyToken(token);
    assert.strictEqual(session, null, "Revoked token must return null");
  });

  // 2. Sensitive Log Redaction Tests
  test("Security: Redact API keys, tokens, and passwords in logs", () => {
    const input = "Connecting with sk-1234567890abcdef1234 and AIzaSyBJN3ZYdzTmjyQJ-9TdpikbsZDT9JUAYFk and password='supersecret'";
    const sanitized = redactSensitive(input);
    assert.ok(!sanitized.includes("sk-1234567890abcdef1234"), "OpenAI key must be redacted");
    assert.ok(!sanitized.includes("AIzaSyBJN3ZYdzTmjyQJ-9TdpikbsZDT9JUAYFk"), "Google key must be redacted");
    assert.ok(!sanitized.includes("supersecret"), "Password must be redacted");
    assert.ok(sanitized.includes("••••••••"), "Must contain redaction marks");
  });

  // 3. System Metrics Tests
  test("System: Real metrics reporting (CPU, RAM, Disk, Process)", () => {
    const m = systemMonitor.getMetrics();
    assert.ok(typeof m.cpu.usagePercent === "number", "CPU usage must be a number");
    assert.ok(typeof m.memory.percent === "number", "RAM percentage must be a number");
    assert.ok(m.memory.total > 0, "Total RAM must be > 0");
    assert.ok(m.process.pid === process.pid, "PID must match current process");
    assert.ok(m.host.hostname, "Hostname must exist");
  });

  // 4. Kobeni Service Integration Tests
  test("KobeniService: Read settings", () => {
    const s = kobeniService.getSettings();
    assert.ok(s.owner, "Owner should exist");
    assert.ok(Array.isArray(s.prefix), "Prefix should be array");
  });

  test("KobeniService: Public/Self mode get and set", () => {
    const current = kobeniService.getMode("main");
    assert.ok(typeof current.isPublic === "boolean", "isPublic must be boolean");

    // Toggle and check
    kobeniService.setMode("main", false);
    const selfMode = kobeniService.getMode("main");
    assert.strictEqual(selfMode.isPublic, false, "Should be SELF mode");

    kobeniService.setMode("main", true);
    const publicMode = kobeniService.getMode("main");
    assert.strictEqual(publicMode.isPublic, true, "Should be PUBLIC mode");
  });

  await testAsync("KobeniService: Plugin scanner and categorization", async () => {
    const data = await kobeniService.getPlugins();
    assert.ok(data.totalPlugins > 0, "Plugins should be found");
    assert.ok(data.totalCommands > 0, "Commands should be found");
    assert.ok(data.categories.length > 0, "Categories should be found");
    assert.ok(Array.isArray(data.plugins), "Flat plugins list should exist");
    assert.ok(data.plugins.length > 0, "Flat plugins list should have items");
  });

  await testAsync("KobeniService: Plugin CRUD & Syntax error tagging", async () => {
    // 1. Create valid plugin
    const validCode = `let handler = async (m) => { m.reply("ok"); }; handler.command = ["smoketest"]; export default handler;`;
    const created = await kobeniService.createPlugin("tools", "smoketest_temp.js", validCode);
    assert.strictEqual(created.success, true);
    assert.strictEqual(created.hasSyntaxError, false);

    // 2. Read back
    const detail = await kobeniService.getPluginContent("tools", "smoketest_temp.js");
    assert.strictEqual(detail.hasSyntaxError, false);

    // 3. Update with syntax error
    const invalidCode = `let handler = async (m) => { m.reply("oops"; }; handler.command = ["smoketest"]; export default handler;`;
    const savedError = await kobeniService.savePlugin("tools", "smoketest_temp.js", invalidCode);
    assert.strictEqual(savedError.success, true);
    assert.strictEqual(savedError.hasSyntaxError, true);
    assert.ok(savedError.syntaxError, "Syntax error must be reported");

    // 4. Verify getPlugins tags the syntax error
    const plugins = await kobeniService.getPlugins();
    const tagged = plugins.plugins.find(p => p.filename === "smoketest_temp.js");
    assert.ok(tagged, "Plugin must be in list");
    assert.strictEqual(tagged.hasSyntaxError, true, "Must be tagged with hasSyntaxError = true");
    assert.strictEqual(tagged.isLoaded, false, "Broken plugin must not be loaded into memory");

    // 5. Clean up
    const deleted = await kobeniService.deletePlugin("tools", "smoketest_temp.js");
    assert.strictEqual(deleted.success, true);
  });

  // 5. Main Bot Process Manager Tests
  test("BotProcessManager: Main Bot status reporting & dynamic pairing code", () => {
    botProcessManager.pairingCode = "NCT985TT";
    botProcessManager.pairingTargetNumber = "60143415586";
    botProcessManager.status = "PAIRING";

    const status = botProcessManager.getMainBotStatus();
    assert.strictEqual(status.id, "main");
    assert.strictEqual(status.pairingState.code, "NCT985TT", "Dynamic WhatsApp pairing code must be returned");
    assert.strictEqual(status.pairingState.targetNumber, "60143415586");
    assert.strictEqual(status.status, "PAIRING");

    // Reset status back to STOPPED
    botProcessManager.status = "STOPPED";
    botProcessManager.pairingCode = null;
  });

  console.log(`\n=== TEST RESULTS: ${passed} PASSED, ${failed} FAILED ===\n`);
  if (failed > 0) {
    process.exit(1);
  }
}

runTests();
