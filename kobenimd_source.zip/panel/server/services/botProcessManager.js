import fs from "fs-extra";
import path from "node:path";
import { config } from "../config.js";
import { logService } from "./logService.js";
import { realTimeService } from "./realTimeService.js";
import { addBot, delBot, listBot, startAllBot } from "../../../outdex.js";
import baileys from "@whiskeysockets/baileys";

const makeWASocket = baileys.default || baileys.makeWASocket;
const { useMultiFileAuthState, DisconnectReason } = baileys;

const silentLogger = (baileys.DEFAULT_CONNECTION_CONFIG?.logger?.child?.({}) || {
  level: "silent",
  info: () => {},
  error: () => {},
  warn: () => {},
  debug: () => {},
  trace: () => {},
  child: () => silentLogger,
});
silentLogger.level = "silent";

class BotProcessManager {
  constructor() {
    this.mainSocket = null;
    this.status = "STOPPED"; // ONLINE, CONNECTING, RECONNECTING, PAIRING, STOPPED, CRASHED
    this.startedAt = null;
    this.lastConnection = null;
    this.lastDisconnect = null;
    this.reconnectCount = 0;
    this.pairingCode = null;
    this.pairingCodeCreatedAt = null;
    this.pairingTargetNumber = null;
    this.isStarting = false;
    this.isStopping = false;
    this.mainNumber = null;
    this.crashCount = 0;
    this.lastCrashTime = null;
  }

  registerMainSocket(conn) {
    this.mainSocket = conn;
    this.status = conn.authState?.creds?.registered ? "CONNECTING" : "PAIRING";
    if (this.status === "PAIRING") {
      this.pairingTargetNumber = global.owner || "601112260297";
      this.pairingCode = global.pairingcode || "KOBENIMD";
    }

    conn.ev.on("connection.update", ({ connection, lastDisconnect }) => {
      if (connection === "open") {
        this.status = "ONLINE";
        this.startedAt = Date.now();
        this.lastConnection = new Date().toISOString();
        this.crashCount = 0;
        this.pairingCode = null;
        if (conn.user?.id) {
          this.mainNumber = conn.user.id.split(":")[0];
        }
        realTimeService.broadcastBotStatus("main", "ONLINE", { number: this.mainNumber });
      } else if (connection === "close") {
        this.lastDisconnect = new Date().toISOString();
        if (this.status !== "STOPPED") {
          this.status = "RECONNECTING";
          this.reconnectCount++;
          realTimeService.broadcastBotStatus("main", "RECONNECTING", { count: this.reconnectCount });
        }
      }
    });
  }

  getMainBotStatus() {
    const sessionExists = fs.existsSync(path.join(config.sessionDir, "creds.json"));
    let extractedNumber = this.mainNumber;

    if (!extractedNumber && sessionExists) {
      try {
        const creds = fs.readJsonSync(path.join(config.sessionDir, "creds.json"));
        if (creds?.me?.id) {
          extractedNumber = creds.me.id.split(":")[0];
          this.mainNumber = extractedNumber;
        }
      } catch (_e) {}
    }

    const uptimeSeconds = this.startedAt ? Math.floor((Date.now() - this.startedAt) / 1000) : 0;

    return {
      id: "main",
      name: "Kobeni-MD Main Bot",
      status: this.status,
      number: extractedNumber || global.owner || "601112260297",
      pid: process.pid,
      uptimeSeconds,
      uptimeFormatted: this.formatUptime(uptimeSeconds),
      lastConnection: this.lastConnection,
      lastDisconnect: this.lastDisconnect,
      reconnectCount: this.reconnectCount,
      pairingState: {
        isWaiting: this.status === "PAIRING",
        code: this.pairingCode || (this.status === "PAIRING" ? "REQUESTING..." : null),
        targetNumber: this.pairingTargetNumber || global.owner || null,
      },
      sessionState: {
        hasSession: sessionExists,
        sessionDir: "session/",
      },
      memory: {
        rss: Math.round(process.memoryUsage().rss / 1024 / 1024) + " MB",
        heapUsed: Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + " MB",
      }
    };
  }

  formatUptime(seconds) {
    if (!seconds || seconds <= 0) return "0s";
    const d = Math.floor(seconds / 86400);
    const h = Math.floor((seconds % 86400) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (d > 0) return `${d}d ${h}h ${m}m`;
    if (h > 0) return `${h}h ${m}m ${s}s`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
  }

  async startMainBot(customNumber = null) {
    if (this.status === "ONLINE" || this.status === "CONNECTING") {
      logService.add("WARN", "BOT", "Main bot is already running or connecting.");
      return { success: false, message: "Main bot is already running", bot: this.getMainBotStatus() };
    }

    if (this.isStarting) {
      return { success: false, message: "Main bot start is already in progress", bot: this.getMainBotStatus() };
    }

    // Set custom target pairing number if provided
    if (customNumber) {
      const cleanNum = String(customNumber).replace(/[^0-9]/g, "");
      if (cleanNum && cleanNum.length >= 7) {
        if (this.pairingTargetNumber !== cleanNum) {
          this.pairingCode = null;
          this.pairingCodeCreatedAt = null;
        }
        this.pairingTargetNumber = cleanNum;
      }
    }

    if (!this.pairingTargetNumber) {
      this.pairingTargetNumber = String(global.owner || "601112260297").replace(/[^0-9]/g, "");
    }

    this.isStarting = true;
    this.status = "CONNECTING";
    realTimeService.broadcastBotStatus("main", "CONNECTING");
    logService.add("INFO", "BOT", `Starting Main Bot process (Target Phone: ${this.pairingTargetNumber})...`);

    try {
      fs.ensureDirSync(config.sessionDir);
      const { state, saveCreds } = await useMultiFileAuthState(config.sessionDir);

      let version = [2, 3000, 1015901307];
      if (typeof baileys.fetchLatestBaileysVersion === "function") {
        try {
          const v = await baileys.fetchLatestBaileysVersion();
          if (v?.version) version = v.version;
        } catch (_e) {}
      }

      const connectionOptions = {
        version,
        logger: silentLogger,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: false,
        auth: state,
        browser: baileys.Browsers?.ubuntu ? baileys.Browsers.ubuntu("Chrome") : ["Ubuntu", "Chrome", "20.0.04"],
        markOnlineOnConnect: false,
        generateHighQualityLinkPreview: false,
        getMessage: async () => ({ conversation: "kyahh" }),
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 60000,
        retryRequestDelayMs: 500,
        syncFullHistory: false,
      };

      const conn = makeWASocket(connectionOptions);
      this.mainSocket = conn;

      // Apply pathconn extension
      try {
        const mod = await import(`../../../system/lib/pathconn.js?t=${Date.now()}`);
        mod.default(conn);
      } catch (err) {
        logService.add("WARN", "SYSTEM", `pathconn warning: ${err.message}`);
      }

      // Check pairing code if not registered
      if (!conn.authState.creds.registered) {
        this.status = "PAIRING";
        const targetNumber = String(this.pairingTargetNumber).replace(/[^0-9]/g, "");

        // If we already have a valid active pairing code generated less than 120s ago, keep it
        const codeAge = this.pairingCodeCreatedAt ? (Date.now() - this.pairingCodeCreatedAt) : Infinity;
        if (this.pairingCode && codeAge < 120000) {
          logService.add("INFO", "BOT", `Using active pairing code: ${this.pairingCode} for +${targetNumber}`);
          realTimeService.broadcastPairingCode("main", this.pairingCode, targetNumber);
        } else {
          this.pairingCode = null; // Reset expired or empty code
          realTimeService.broadcastBotStatus("main", "PAIRING", {
            code: "REQUESTING...",
            targetNumber,
          });
          logService.add("INFO", "BOT", `Main Bot requesting pairing code for WhatsApp number: +${targetNumber}...`);

          // Request pairing with stable handshake delay
          setTimeout(async () => {
            try {
              if (this.mainSocket && !this.mainSocket.authState.creds.registered) {
                // Request code directly from WhatsApp with clean number string ONLY (no extra custom arguments)
                const code = await this.mainSocket.requestPairingCode(targetNumber);
                if (code) {
                  this.pairingCode = code;
                  this.pairingCodeCreatedAt = Date.now();
                  realTimeService.broadcastPairingCode("main", code, targetNumber);
                  logService.add("INFO", "BOT", `╔═══════════════════════════════════════════════════════════╗`);
                  logService.add("INFO", "BOT", `║  🌸 WHATSAPP PAIRING CODE: ${String(code).padEnd(30)} ║`);
                  logService.add("INFO", "BOT", `║  Phone Number: +${String(targetNumber).padEnd(41)} ║`);
                  logService.add("INFO", "BOT", `║  👉 Enter code on WhatsApp: Linked Devices > Link Device  ║`);
                  logService.add("INFO", "BOT", `╚═══════════════════════════════════════════════════════════╝`);
                }
              }
            } catch (e) {
              logService.add("WARN", "BOT", `Pairing code request note: ${e.message || "Waiting for WhatsApp server response"}`);
            }
          }, 2500);
        }
      }

      // Connection event listeners
      conn.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        if (connection === "open") {
          this.status = "ONLINE";
          this.startedAt = Date.now();
          this.lastConnection = new Date().toISOString();
          this.crashCount = 0;
          this.pairingCode = null;
          this.pairingCodeCreatedAt = null;
          this.reconnectCount = 0;

          if (conn.user?.id) {
            this.mainNumber = conn.user.id.split(":")[0];
          }

          realTimeService.broadcastBotStatus("main", "ONLINE", { number: this.mainNumber });
          logService.add("INFO", "BOT", `[MAIN] WhatsApp Connected successfully! (${this.mainNumber || "OK"})`);
          return;
        }

        if (connection === "close") {
          this.lastDisconnect = new Date().toISOString();
          const reason = lastDisconnect?.error?.output?.statusCode ||
                         lastDisconnect?.error?.statusCode ||
                         lastDisconnect?.error?.cause?.statusCode;

          logService.add("WARN", "BOT", `Main Bot connection closed (reason: ${reason || "unknown"})`);

          const isRegistered = Boolean(conn.authState?.creds?.registered || fs.existsSync(path.join(config.sessionDir, "creds.json")));

          // Only treat as true logout if account was already paired and registered
          if (isRegistered && reason === DisconnectReason.loggedOut) {
            this.status = "STOPPED";
            this.pairingCode = null;
            this.pairingCodeCreatedAt = null;
            realTimeService.broadcastBotStatus("main", "STOPPED");
            logService.add("ERROR", "BOT", "Main Bot session logged out from phone.");
            return;
          }

          // If in pairing state or temporary disconnect, keep state and reconnect gracefully without stopping
          if (this.status !== "STOPPED") {
            this.reconnectCount++;
            if (!isRegistered) {
              this.status = "PAIRING";
              logService.add("INFO", "BOT", `Pairing standby (code: ${this.pairingCode || "waiting"}). Waiting for user to enter pairing code on WhatsApp...`);
            } else {
              this.status = "RECONNECTING";
            }
            realTimeService.broadcastBotStatus("main", this.status, { count: this.reconnectCount, code: this.pairingCode });

            // Backoff reconnection
            const delay = !isRegistered ? 5000 : Math.min(30000, 3000 * Math.pow(1.5, Math.min(this.reconnectCount, 5)));
            setTimeout(() => {
              if (this.status !== "STOPPED") {
                this.startMainBot().catch(() => {});
              }
            }, delay);
          }
        }
      });

      // Message listener
      conn.ev.on("messages.upsert", async ({ messages, type }) => {
        if (type !== "notify") return;
        const msg = messages[0];
        if (!msg?.message || msg.key?.remoteJid === "status@broadcast") return;

        try {
          const { smsg } = await import(`../../../system/lib/smsg.js?t=${Date.now()}`);
          const handlerMod = await import(`../../../system/handler.js?t=${Date.now()}`);
          const m = smsg(conn, msg);
          const senderNum = m.sender ? m.sender.split("@")[0] : "unknown";
          logService.add("INFO", "MSG", `Incoming command/message from ${senderNum}`);
          await handlerMod.default(conn, m, msg);
        } catch (e) {
          logService.add("ERROR", "BOT", `Handler error: ${e.message}`);
        }
      });

      conn.ev.on("creds.update", saveCreds);

      // Start all clones if any
      startAllBot().catch(err => {
        logService.add("WARN", "CLONE", `startAllBot notice: ${err.message}`);
      });

      this.isStarting = false;
      return { success: true, message: "Main bot started successfully", bot: this.getMainBotStatus() };
    } catch (err) {
      this.isStarting = false;
      this.status = "CRASHED";
      this.lastCrashTime = new Date().toISOString();
      this.crashCount++;
      realTimeService.broadcastBotStatus("main", "CRASHED", { error: err.message });
      logService.add("ERROR", "BOT", `Failed to start Main Bot: ${err.message}`);
      throw err;
    }
  }

  async stopMainBot() {
    if (this.status === "STOPPED") {
      return { success: true, message: "Main bot is already stopped" };
    }

    this.isStopping = true;
    logService.add("WARN", "BOT", "Stopping Main Bot process...");

    try {
      if (this.mainSocket) {
        if (this.mainSocket.ev) {
          this.mainSocket.ev.removeAllListeners();
        }
        try {
          this.mainSocket.end(new Error("Stopped via Panel"));
        } catch (_e) {}
        this.mainSocket = null;
      }

      this.status = "STOPPED";
      this.startedAt = null;
      this.isStopping = false;
      this.pairingCode = null;
      realTimeService.broadcastBotStatus("main", "STOPPED");
      logService.add("INFO", "BOT", "Main Bot stopped safely.");

      return { success: true, message: "Main bot stopped", bot: this.getMainBotStatus() };
    } catch (err) {
      this.isStopping = false;
      logService.add("ERROR", "BOT", `Error stopping bot: ${err.message}`);
      throw err;
    }
  }

  async restartMainBot(customNumber = null) {
    logService.add("INFO", "BOT", "Restarting Main Bot...");
    await this.stopMainBot();
    await new Promise(r => setTimeout(r, 1500));
    return await this.startMainBot(customNumber);
  }

  async resetMainSession() {
    logService.add("WARN", "BOT", "DANGER: Resetting Main Bot session...");
    await this.stopMainBot();

    if (fs.existsSync(config.sessionDir)) {
      // Remove all creds and session files, keep bots/
      const botsDir = config.botsDir;
      const tempBots = path.join(config.rootDir, ".temp_bots_" + Date.now());
      if (fs.existsSync(botsDir)) {
        fs.moveSync(botsDir, tempBots);
      }
      fs.rmSync(config.sessionDir, { recursive: true, force: true });
      fs.ensureDirSync(config.sessionDir);
      if (fs.existsSync(tempBots)) {
        fs.moveSync(tempBots, botsDir);
      }
    }

    this.mainNumber = null;
    this.pairingCode = null;
    logService.add("INFO", "BOT", "Main session wiped. Bot is ready for new pairing.");
    return { success: true, message: "Session reset successfully" };
  }

  // --- Clone Bot Lifecycle ---
  async startClone(id) {
    const cleanId = String(id).replace(/[^0-9]/g, "");
    logService.add("INFO", "CLONE", `Starting clone bot ${cleanId}...`);
    return await addBot(cleanId, true);
  }

  async stopClone(id) {
    const cleanId = String(id).replace(/[^0-9]/g, "");
    logService.add("WARN", "CLONE", `Stopping clone bot ${cleanId}...`);
    return delBot(cleanId, true);
  }

  async restartClone(id) {
    const cleanId = String(id).replace(/[^0-9]/g, "");
    logService.add("INFO", "CLONE", `Restarting clone bot ${cleanId}...`);
    await this.stopClone(cleanId);
    await new Promise(r => setTimeout(r, 1000));
    return await this.startClone(cleanId);
  }
}

export const botProcessManager = new BotProcessManager();
