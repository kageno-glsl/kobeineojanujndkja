import { authService } from "../services/authService.js";

// Helper to extract cookies from request header
function parseCookies(req) {
  const list = {};
  const cookieHeader = req.headers.cookie;
  if (!cookieHeader) return list;

  cookieHeader.split(";").forEach((cookie) => {
    let [name, ...rest] = cookie.split("=");
    name = name?.trim();
    if (!name) return;
    const value = rest.join("=").trim();
    list[name] = decodeURIComponent(value);
  });
  return list;
}

export function requireAuth(req, res, next) {
  // Check cookie or Bearer token
  const cookies = parseCookies(req);
  const cookieToken = cookies["kobeni_session"];
  
  let token = cookieToken;
  if (!token && req.headers.authorization) {
    const parts = req.headers.authorization.split(" ");
    if (parts[0] === "Bearer" && parts[1]) {
      token = parts[1];
    }
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      error: {
        code: "UNAUTHORIZED",
        message: "Authentication required to access this resource",
      }
    });
  }

  const session = authService.verifyToken(token);
  if (!session) {
    return res.status(401).json({
      success: false,
      error: {
        code: "SESSION_EXPIRED",
        message: "Invalid or expired session. Please login again.",
      }
    });
  }

  req.user = session;
  req.sessionToken = token;
  next();
}

export function optionalAuth(req, res, next) {
  const cookies = parseCookies(req);
  const token = cookies["kobeni_session"] || (req.headers.authorization?.startsWith("Bearer ") ? req.headers.authorization.split(" ")[1] : null);

  if (token) {
    const session = authService.verifyToken(token);
    if (session) {
      req.user = session;
    }
  }
  next();
}
