// Path traversal and parameter sanitization
export function validateBotId(req, res, next) {
  const id = req.params.id;
  if (!id) {
    return res.status(400).json({
      success: false,
      error: { code: "INVALID_PARAM", message: "Bot ID is required" }
    });
  }

  // Allow "main" or digit-only clone IDs
  if (id !== "main" && !/^\d{5,20}$/.test(id)) {
    return res.status(400).json({
      success: false,
      error: { code: "INVALID_BOT_ID", message: "Bot ID must be 'main' or a valid WhatsApp number (5-20 digits)" }
    });
  }

  // Reject traversal attempts
  if (id.includes("..") || id.includes("/") || id.includes("\\") || id.includes("\0")) {
    return res.status(400).json({
      success: false,
      error: { code: "ILLEGAL_PATH", message: "Path traversal characters detected" }
    });
  }

  next();
}

export function validatePhoneNumber(req, res, next) {
  const number = req.body.number || req.params.number;
  if (!number) {
    return res.status(400).json({
      success: false,
      error: { code: "MISSING_PHONE", message: "Phone number is required" }
    });
  }

  const clean = String(number).replace(/[^0-9]/g, "");
  if (!/^\d{5,20}$/.test(clean)) {
    return res.status(400).json({
      success: false,
      error: { code: "INVALID_PHONE", message: "Phone number must be between 5 and 20 digits" }
    });
  }

  req.cleanNumber = clean;
  next();
}

export function validatePluginCategory(req, res, next) {
  const cat = req.params.category;
  if (cat && (!/^[a-zA-Z0-9_\-]+$/.test(cat) || cat.includes(".."))) {
    return res.status(400).json({
      success: false,
      error: { code: "INVALID_CATEGORY", message: "Invalid category name" }
    });
  }
  next();
}
