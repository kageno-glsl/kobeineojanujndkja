// In-memory rate limiter per IP address
const ipHits = new Map();

export function createRateLimiter({ windowMs = 60000, max = 30, message = "Too many requests. Please try again later." }) {
  return (req, res, next) => {
    const ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress || "unknown";
    const now = Date.now();

    if (!ipHits.has(ip)) {
      ipHits.set(ip, []);
    }

    const timestamps = ipHits.get(ip);
    // Remove expired timestamps
    while (timestamps.length && timestamps[0] <= now - windowMs) {
      timestamps.shift();
    }

    if (timestamps.length >= max) {
      return res.status(429).json({
        success: false,
        error: {
          code: "RATE_LIMITED",
          message,
          retryAfter: Math.ceil((timestamps[0] + windowMs - now) / 1000),
        }
      });
    }

    timestamps.push(now);
    next();
  };
}

export const loginLimiter = createRateLimiter({
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 8,                  // max 8 attempts per 5 mins
  message: "Too many login attempts. Please wait 5 minutes before trying again."
});

export const mutationLimiter = createRateLimiter({
  windowMs: 60 * 1000,     // 1 minute
  max: 60,                 // 60 actions per min
  message: "Too many actions requested. Please slow down."
});
